package com.tasker.issue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IssueManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
