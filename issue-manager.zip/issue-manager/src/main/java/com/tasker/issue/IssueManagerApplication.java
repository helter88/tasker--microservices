package com.tasker.issue;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IssueManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(IssueManagerApplication.class, args);
	}

}
